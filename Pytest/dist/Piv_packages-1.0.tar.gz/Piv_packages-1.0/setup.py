from setuptools import setup, find_packages

setup(
    name='Piv_packages',
    description='Packages for piv Api interactions',

    version='1.0',
    author='Sohaib Khan',
    author_email='sohaib.khan@penninteractive.com',
    url='https://github.com/penngineering/testing',

    packages=find_packages(where='Piv_packages'),
    package_dir={'': 'Piv_packages'},
)
